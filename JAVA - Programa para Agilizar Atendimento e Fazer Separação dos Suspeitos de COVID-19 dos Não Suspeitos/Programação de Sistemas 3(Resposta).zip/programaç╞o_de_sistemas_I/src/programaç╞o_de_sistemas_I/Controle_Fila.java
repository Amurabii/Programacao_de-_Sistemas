package programa��o_de_sistemas_I;

import java.util.Scanner;

public class Controle_Fila {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);	
		
		System.out.println("Digite seu CPF: ");
		int CPF = sc.nextInt();
		System.out.println("Digite seu nome: ");
		String Nome = sc.next();
		System.out.println("Digite seu sexo: ");
		char Sexo = sc.next().charAt(0);
		System.out.println("Digite sua idade: ");
		int Idade = sc.nextInt();
		
		
		double febre = 5,dorDeCabeca = 1,secrecaoNasalOuEspirros = 1;
		double dorOuIrritacaoGarganta = 1, tosseSeca = 3, dificuldadeRespirar = 10;
		double doresNoCorpo = 1, diarreia = 1, contatoComAlguemComCovidUlt14Dias = 10;
		double esteveEmLocaisComGrandeAglomeracao = 3;
		char s = 'S';
		char n = 'N';
		double soma = 0;
		
		
		System.out.println("Tem febre?");
		char condi��o = sc.next().charAt(0);
		
		if(condi��o == 'S') {
			soma =  soma + febre;
		}else {
				
		}
		
		
		System.out.println("Tem dor de cabe�a?");
		char condi��o1 = sc.next().charAt(0);
		
		if(condi��o1 == 'S') {
			soma =  soma + dorDeCabeca;
		}else {
				
		}
		
		
		System.out.println("Tem secre��o nasal ou espirros?");
		char condi��o2 = sc.next().charAt(0);
		
		if(condi��o2 == 'S') {
			soma =  soma + secrecaoNasalOuEspirros ;
		}else {
				
		}
		
		
		System.out.println("Tem dor/irrita��o na garganta?");
		char condi��o3 = sc.next().charAt(0);
		
		if(condi��o3 == 'S') {
			soma =  soma + dorOuIrritacaoGarganta ;
		}else {
			
		}
		
		
		System.out.println("Tem tosse seca?");
		char condi��o4 = sc.next().charAt(0);
		
		if(condi��o4 == 'S') {
			soma =  soma + tosseSeca ;
		}else {
				
		}
		
		
		System.out.println("Tem dificuldade respirat�ria?");
		char condi��o5 = sc.next().charAt(0);
		
		if(condi��o5 == 'S') {
			soma =  soma + dificuldadeRespirar ;
		}else {
				
		}
		
		
		System.out.println("Tem dores no corpo?");
		char condi��o6 = sc.next().charAt(0);
		
		if(condi��o6 == 'S') {
			soma =  soma + 	doresNoCorpo ;
		}else {
				
		}
	
		
		System.out.println("Tem diarreia?");
		char condi��o7 = sc.next().charAt(0);
		
		if(condi��o7 == 'S') {
			soma =  soma + 	diarreia ;
		}else {
				
		}
		
		
		System.out.println("Esteve em contato, nos �ltimos 14 dias, com um caso diagnosticado com COVID-19? ");
		char condi��o8 = sc.next().charAt(0);
		
		if(condi��o8 == 'S') {
			soma =  soma + 	contatoComAlguemComCovidUlt14Dias ;
		}else {
				
		}
		
		
		System.out.println("Esteve em locais com grande aglomera��o?");
		char condi��o9 = sc.next().charAt(0);
		
		if(condi��o9 == 'S') {
			soma =  soma + 	esteveEmLocaisComGrandeAglomeracao ;
		}else {
				
		}
		
		

		double somaTotal = soma; 
		System.out.println("A soma total deu: " + somaTotal);
		
		if(somaTotal <= 9) {
			System.out.println("V� para ala de Risco Baixo");
		}else if(somaTotal <= 19) {
			System.out.println("V� para ala de Risco M�dio");
		}else {
			System.out.println("V� para ala de Risco Alto");
		}
		
		System.out.println();
		
		Paciente[] listaPaciente = new Paciente[4];
		Paciente p1 = new Paciente();
		p1.setCPF(125784215);
		p1.setNome("Barry Allen");
		p1.setSexo('M');
		p1.setIdade(36);
		
		Paciente p2 = new Paciente();
		p2.setCPF(125445215);
		p2.setNome("Jesse quick");
		p2.setSexo('F');
		p2.setIdade(26); 
		
		listaPaciente[0] = p1;
		listaPaciente[1] = p2;
		
		for(int a = 0; a < 2; a ++) {
			System.out.println(listaPaciente[a].getCPF());
			System.out.println(listaPaciente[a].getNome());
			System.out.println(listaPaciente[a].getSexo());
			System.out.println(listaPaciente[a].getIdade());
		}

		String sair = "SAIR";
		System.out.println("Digite seu CPF: ");
		String CPF1 = sc.next();
		
		if(CPF1.equals(sair)) {
			System.out.println("Encerrado");
			
		}
		else {
			
			System.out.println("Digite seu nome: ");
			String Nome1 = sc.next();
			System.out.println("Digite seu sexo: ");
			char Sexo1 = sc.next().charAt(0);
			System.out.println("Digite sua idade: ");
			int Idade1 = sc.nextInt();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		sc.close();

	}

}
