package programa��o_de_sistemas_I;

public class Paciente {
	int CPF;
	String Nome;
	char Sexo;
	int Idade;
	
	
	public Paciente() {
		
	}
	
	public int CPF(int CPF) {
		return CPF;
	}
	
	public String Nome(String Nome) {
		return Nome;
	}
	
	public char Sexo(char Sexo) {
		return Sexo;
	}
	
	public int Idade(int Idade) {
		return Idade;
	}

	
	
	public int getCPF() {
		return CPF;
	}

	public void setCPF(int cPF) {
		CPF = cPF;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		this.Nome = nome;
	}

	public char getSexo() {
		return Sexo;
	}

	public void setSexo(char sexo) {
		this.Sexo = sexo;
	}

	public int getIdade() {
		return Idade;
	}

	public void setIdade(int idade) {
		this.Idade = idade;
	}
	
	
	
}
	 
	