package prog1_atv1;

import java.util.Scanner;

public class Salva_vidas {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.printf("Digite a �rea: %n");
		
		double  R ,�rea, pi = 3.1415;
		
		R = sc.nextDouble();
		�rea = pi * (R * R );
		
		System.out.printf("O valor da �rea � : %.2f%n",�rea);
		
		if(�rea <= 1000){
			System.out.println("Vai 1 Salva Vidas");
		}
		else if( �rea <= 10000 ){
			System.out.println("V�o 2 Salva Vidas");
		}
		else if ( �rea <= 100000 ){
			System.out.println("V�o 3 Salva Vidas");
		}
		else {
			System.out.println("V�o 4 Salva Vidas");
		}
		
		
		sc.close();
	}

}		
		
		
		
		
		
		
		

